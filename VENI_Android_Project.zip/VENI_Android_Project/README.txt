VENI Android project (prototype)

This is a complete Android Studio/Gradle project configured to build a debug APK in GitHub Actions.
It is not itself an APK yet. The build workflow is .github/workflows/build-apk.yml.

Build from an Android phone:
1. Extract this ZIP.
2. Create a new GitHub repository named VENI (public or private is okay).
3. Upload the CONTENTS of this folder to the repository root (so app/, build.gradle, settings.gradle and .github/ are at the top level).
4. In the repository, tap Actions. If GitHub asks, enable Actions.
5. Select “Build VENI APK” in the left list, tap “Run workflow”, then “Run workflow” again.
6. Wait until the workflow is green. Open the completed run and find Artifacts near the bottom.
7. Download “VENI-debug-APK”, extract it, then tap app-debug.apk to install. If Android asks, allow your browser/file manager to install unknown apps.

Important:
- Never share your GitHub token or password.
- This is a prototype. AI photo recognition and real reminder notifications are not implemented; meal calorie values are user-entered estimates.
- The workflow has not been run from this environment, so the APK build still needs to be confirmed by GitHub Actions.
